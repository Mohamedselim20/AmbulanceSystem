#include "Car.h"
#include "math.h"

void Car::setStatus(int status)
{
	this->status = status;
}

int Car::getStatus() const
{
	return status;
}

void Car::setSpeed(int speed)
{
	this->speed = speed;
}

int Car::getSpeed() const
{
	return speed;
}

void Car::print() const {
	cout << "[Car ID: " << id << ", Type: " << (type == 0 ? "NC" : "SC")
		<< ", Status: " << status << "]";
}


Patient* Car::getPatient() const
{
	return assigned_patient;
}

void Car::setType(int type)
{
	this->type = type;
}


void Car::setNext(Car* next)
{
	this->next = next;
}

Car* Car::getNext() const
{
	return next;
}



int Car::assign_patient(Patient* patient, int ct)
{
	assigned_patient = patient;
	assignment_time = ct;
	pickup_time = assignment_time + ceil(double(patient->getDistance()) / double(speed));
	finish_time = pickup_time + ceil(double(patient->getDistance()) / double(speed));
	return finish_time;
}

int Car::getFinish_time() const
{
	return finish_time;
}

int Car::getID() const
{
	return id;
}

void Car::setID(int id)
{
	this->id = id;
}

int Car::gettype() const
{
	return type;
}
int Car::getHID() const
{
	return hid;
}

void Car::setHID(int hid)
{
	this->hid = hid;
}

void Car::print()
{
	if (type == 1)
	{
		cout << "S";
	}
	else
	{
		cout << "N";
	}
	if (assigned_patient)
	{
		cout << id << "_H" << hid << "_P" << assigned_patient->getPID();
	}
	else
	{
		cout << id << "_H" << hid;
	}
}

int Car::getPickup_time() const
{
	return pickup_time;
}

void Car::removePatient() {
	assigned_patient = nullptr;
	pickup_time = 0;
	finish_time = 0;
	assignment_time = 0;
}

