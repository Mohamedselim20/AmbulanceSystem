#include "LinkedQueue.h"



class NPQueue : public LinkedQueue<NP*>
{
public:
	Node<NP*>* cancel(int pid);
};

class SPQueue : public LinkedQueue<SP*>
{

};

