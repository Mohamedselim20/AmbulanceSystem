#include "PatientQueue.h"

class Car {
    int status;
    int speed;
    Patient* assigned_patient;
    Car* next;
    int pickup_time;
    int finish_time;
    int* current_time;
    int assignment_time;
    int id;
    int hid;
 
    int type;

    int checkup_time;     
    int checkup_end_time;  



public:
    Car() {
        hid = 0;
        status = 0;
        speed = 0;
        type = 0;
        pickup_time = 0;
        finish_time = 0;
        id = 0;
        current_time = new int(0);
        assignment_time = 0;
        assigned_patient = nullptr;
        next = nullptr;

        // Initialize checkup attributes
        checkup_time = 0;
        checkup_end_time = -1; // -1 indicates no checkup is currently scheduled
    }

    Car(int speed, int type, int id, int hid) {
        status = 0;
        assigned_patient = nullptr;
        this->speed = speed;
        this->type = type;
        next = nullptr;
        pickup_time = 0;
        finish_time = 0;
        this->id = id;
        current_time = new int(0);
        assignment_time = 0;
        this->hid = hid;

        // Initialize checkup attributes
        checkup_time = 0;
        checkup_end_time = -1; // -1 indicates no checkup is currently scheduled
    }

    void setStatus(int status);
    int getStatus() const;

    void setSpeed(int speed);
    int getSpeed() const;

    int assign_patient(Patient* patient, int ct);
    Patient* getPatient() const;

    void setType(int type);

    void setNext(Car* next);
    Car* getNext() const;

    int getPickup_time() const;
    int getFinish_time() const;
    int getID() const;
    void setID(int id);
    int gettype() const;
    int getHID() const;
    void setHID(int hid);
    void print();
    void removePatient();
    void print() const;
    void setCheckupTime(int time) { checkup_time = time; }
    int getCheckupTime() const { return checkup_time; }

    void startCheckup(int current_time) {
        checkup_end_time = current_time + checkup_time;
    }

    int getCheckupEndTime() const { return checkup_end_time; }

    bool isCheckupComplete(int current_time) const {
        return current_time >= checkup_end_time;
    }
};
