#include "Patient.h"
using namespace std;

Patient::Patient()
{
	pid = 0, hid = 0, distance = 0;
	picked = false;
	next = nullptr;
	request_time = -1;
}

Patient::Patient(int request_time, int pid, int hid, int distance)
{
	this->pid = pid;
	this->hid = hid;
	this->distance = distance;
	this->request_time = request_time;
	picked = false;
	next = nullptr;
}

void Patient::setPID(int new_pid)
{
	pid = new_pid;
}

void Patient::setHID(int new_hid)
{
	hid = new_hid;
}

void Patient::setDistance(int new_distance)
{
	distance = new_distance;
}

void Patient::setNext(Patient* nextPatientPtr)
{
	next = nextPatientPtr;
}

void Patient::setPicked(bool picked)
{
	this->picked = picked;
}

void Patient::setRequestTime(int request_time)
{
	this->request_time = request_time;
}

int Patient::getPID() const
{
	return pid;
}

int Patient::getHID() const
{
	return hid;
}

int Patient::getDistance() const
{
	return distance;
}

bool Patient::getPicked() const
{
	return picked;
}

Patient* Patient::getNext() const
{
	return next;
}

int Patient::getRequestTime() const
{
	return request_time;
}

Patient::~Patient()
{
}

void EP::setSeverity(int severity)
{
	this->severity = severity;
}

int EP::getSeverity() const
{
	return severity;
}



void NP::setCancelTime(int cancel_time)
{
	this->cancel_time = cancel_time;
}

int NP::getCancelTime() const
{
	return cancel_time;
}

void NP::print() const
{
	cout << "NP " << getRequestTime() << " " << getPID() << " " << getHID() << " " << getDistance();
}

void SP::print() const
{
	cout << "SP " << getRequestTime() << " " << getPID() << " " << getHID() << " " << getDistance();
}

void EP::print() const
{
	cout << "EP " << getRequestTime() << " " << getPID() << " " << getHID() << " " << getDistance() << " "  << getSeverity();
}
