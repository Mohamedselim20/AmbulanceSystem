// All patients have these common attributes and behaviors, so lets just
// inherit from a base "patient class"
#include <iostream>
class Patient
{
private:
	int pid; // A data item
	int hid;
	int distance;
	bool picked;
	int request_time;

	Patient* next;
public:
	Patient();
	explicit Patient(int request_time, int pid, int hid, int distance);

	void setPID(int new_pid);
	void setHID(int new_hid);
	void setDistance(int  new_distance);
	virtual void setNext(Patient* nextPatientPtr);
	void setPicked(bool picked);
	void setRequestTime(int request_time);

	int getPID() const ;
	int getHID() const ;
	int getDistance() const ;
	bool getPicked() const ;
	Patient* getNext() const;
	int getRequestTime() const;

	virtual ~Patient();
};



class NP : public Patient
{
private:
	int cancel_time = -1;
public:
	using Patient::Patient;
	void setCancelTime(int cancel_time);
	int getCancelTime() const;
	void print() const;
};

class SP : public Patient
{
	using Patient::Patient;
public:
	void print() const;
};

class EP : public Patient
{
private:
	int severity;
public:
	using Patient::Patient;
	void setSeverity(int severity);
	int getSeverity() const;
	void print() const;
};
