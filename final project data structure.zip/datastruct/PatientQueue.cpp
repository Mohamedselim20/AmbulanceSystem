#include "PatientQueue.h"



Node<NP*>* NPQueue::cancel(int pid)
{
	if (isEmpty())
		return nullptr;

	Node<NP*>* cancelled_patient;
	Node<NP*>* delayed_ptr;
	
	delayed_ptr = getFrntEntry();

	Node<NP*>* moving_ptr = delayed_ptr;

	// do this once before entering the while loop to delay the dptr
	if (moving_ptr->getItem()->getPID() == pid)
	{
		cancelled_patient = moving_ptr;
		delayed_ptr->setNext(moving_ptr->getNext());
		return cancelled_patient;
	}
	moving_ptr = moving_ptr->getNext();


	while (moving_ptr)
	{
		if (moving_ptr->getItem()->getPID() == pid)
		{
			// "skip" or "remove" the request from the queue
			cancelled_patient = moving_ptr;
			delayed_ptr->setNext(moving_ptr->getNext());
			return cancelled_patient;
		}

		moving_ptr = moving_ptr->getNext();
		delayed_ptr = delayed_ptr->getNext();
	}
	return nullptr;
}

