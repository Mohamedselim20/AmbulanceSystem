#include "OutCar.h"
void OutCarsQueue::print()
{
	cout << count_q() << " ==> Out cars: ";
	print_noh();
}

Car* OutCarsQueue::cancel(int pid) {
	if (isEmpty())
		return nullptr;

	priNode<Car*>* cancelled_patient;
	priNode<Car*>* delayed_ptr;

	delayed_ptr = head;

	priNode<Car*>* moving_ptr = delayed_ptr;

	int priority;
	// do this once before entering the while loop to delay the dptr
	if (moving_ptr->getItem(priority)->getPatient()->getPID() == pid)
	{
		cancelled_patient = moving_ptr;
		delayed_ptr->setNext(moving_ptr->getNext());
		return cancelled_patient->getItem(priority);
	}
	moving_ptr = moving_ptr->getNext();


	while (moving_ptr)
	{
		if (moving_ptr->getItem(priority)->getPatient()->getPID() == pid)
		{
			// "skip" or "remove" the request from the queue
			cancelled_patient = moving_ptr;
			delayed_ptr->setNext(moving_ptr->getNext());
			return cancelled_patient->getItem(priority);
		}

		moving_ptr = moving_ptr->getNext();
		delayed_ptr = delayed_ptr->getNext();
	}
	return nullptr;
}
