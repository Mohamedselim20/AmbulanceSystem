#include "Organizer.h"
#include "UI.h"
#include <fstream>
#include <sstream>

using namespace std;

void Organizer::add_patient(Patient* new_p)
{
	all_patient_list->enqueue(new_p);
}

void Organizer::add_cancelled_p(NP* new_p)
{
	cancelled_list->enqueue(new_p);
}
void Organizer::add_finished_p(Patient* new_p)
{
	finished_list->enqueue(new_p);
}

int Organizer::getHospNum() const
{
	return num_of_hospitals;
}

void Organizer::setHospNum(int hosp_num)
{
	num_of_hospitals = hosp_num;
}

hospital* Organizer::getHospitals() const
{
	return hospitals;
}


priQueue<Car*>* Organizer::getBackCars() const
{
	return back_cars;
}

void Organizer::add_back_car(Car* c, int pri)
{

	back_cars->enqueue(c, pri);
}

OutCarsQueue* Organizer::getOutCars() const
{
	return out_cars;
}

void Organizer::add_out_car(Car* c, int pri)
{
	out_cars->enqueue(c, pri);
}

bool Organizer::patients_empty()
{
    return (all_patient_list->count_q() == 0);
}
bool Organizer::hospitals_empty()
{
    for (int i = 0; i < num_of_hospitals; i++)
    {
        if (!hospitals[i].isEmpty())
        {
            return false;
        }
    }
    return true;
}

int Organizer::getTime() const
{
	return curtime;
}

void Organizer::setTime(int time)
{
	curtime = time;
}


void Organizer::load() {
    ifstream file;
    file.open("Load/input.txt");

    if (!file.is_open()) {
        cout << "Error opening file!" << endl;
        return;
    }

    file >> num_of_hospitals;
    hospitals = new hospital[num_of_hospitals];
    file >> SCar_speed >> NCar_speed;

    hospitalDistances = new int* [num_of_hospitals];
    for (int i = 0; i < num_of_hospitals; i++) {
        hospitals[i].setID(i + 1);
        hospitalDistances[i] = new int[num_of_hospitals];
    }

    for (int i = 0; i < num_of_hospitals; i++) {
        for (int j = 0; j < num_of_hospitals; j++) {
            file >> hospitalDistances[i][j];
        }
    }

    int Scars, Ncars, SCarCheckupTime, NCarCheckupTime;
    for (int i = 0; i < num_of_hospitals; i++) {
        file >> Scars >> Ncars >> SCarCheckupTime >> NCarCheckupTime;

        for (int j = 0; j < Scars; j++) {
            Car* Sc = new Car(SCar_speed, 1, j + 1, i + 1);
            Sc->setCheckupTime(SCarCheckupTime);
            hospitals[i].addSCar(Sc);
        }

        for (int j = 0; j < Ncars; j++) {
            Car* Nc = new Car(NCar_speed, 0, j + 1, i + 1);
            Nc->setCheckupTime(NCarCheckupTime);
            hospitals[i].addNCar(Nc);
        }
    }

    file >> NumReq;
    int requestTimes, requestPatientID, requestHospitalID, requestDistances;
    string requestType;
    int severity;

    for (int i = 0; i < NumReq; i++)
    {

        file >> requestType;
        
        if (requestType == "NP")
        {
            file >> requestTimes >> requestPatientID >> requestHospitalID >> requestDistances ;
            NP* np = new NP(requestTimes, requestPatientID, requestHospitalID, requestDistances);
			all_patient_list->enqueue(np);
            NumNPReq++;
        }
        if (requestType == "SP")
        {
            file >> requestTimes >> requestPatientID >> requestHospitalID >> requestDistances;
            SP* sp = new SP(requestTimes, requestPatientID, requestHospitalID, requestDistances);
			all_patient_list->enqueue(sp);
            NumSPReq++;
        }
        if (requestType == "EP")
        {
            file >> requestTimes >> requestPatientID >> requestHospitalID >> requestDistances >> severity;
            EP* ep = new EP(requestTimes, requestPatientID, requestHospitalID, requestDistances);
            ep->setSeverity(severity);
			all_patient_list->enqueue(ep);
            NumEPReq++;
        }
    }

    file >> NumCancReq;

    for (int i = 0; i < NumCancReq; i++)
    {
        NP* np;       
        int PID, HID, CT;
        file >> PID >> HID >> CT;
        np = new NP(0,PID, HID, 0);
        np->setCancelTime(CT);
        
        cancelled_list->enqueue(np);
    }

    file.close();
}


bool Organizer::isEmpty()
{
    for (int i = 0; i < num_of_hospitals; i++)
    {
        if (!hospitals[i].isEmpty())
        {
            return false;
        }
    }
    return true;
}


void Organizer::iterate()
{
    Patient* p = nullptr;

    all_patient_list->peek(p);
    if (p && p->getRequestTime() <= curtime)
    {
        all_patient_list->dequeue(p);
        // add patients to hospital lists
        if (dynamic_cast<EP*>(p))
        {
            EP* ep = dynamic_cast<EP*>(p);
            hospitals[ep->getHID() - 1].addEP(ep);
        }
        else if (dynamic_cast<NP*>(p))
        {
            NP* np = dynamic_cast<NP*>(p);
            hospitals[np->getHID() - 1].addNP(np);
        }
        else
        {
            SP* sp = dynamic_cast<SP*>(p);
            hospitals[sp->getHID() - 1].addSP(sp);
        }
    }

    // Cancel patients
    // TODO: Handle case where patient is already served, and the car is already 
    // assigned to him (he's dequeued from the hospital's list, and wont be cancelled with the below function)
    NP* np = nullptr;
    cancelled_list->peek(np);
    if (np && np->getCancelTime() == curtime)
    {
        hospitals[np->getHID() - 1].cancel_np(np);
    }

    // Serve patients
    for (int i = 0; i < num_of_hospitals; i++)
    {
        while (true)
        {
			Car* c = nullptr;
			Patient* p = nullptr;
			p = hospitals[i].serve_patient(c, curtime);
            if (c)
            {
                out_cars->enqueue(c, -c->getPickup_time());
            }
            else if(dynamic_cast<EP*>(p))
            {
                // if EP can not be served, look for other hospital
				bool served = false;
				for (int j = 0; j < num_of_hospitals; j++)
				{
					if (j != i && !hospitals[j].carsIsEmpty())
					{
						hospitals[j].addEP(dynamic_cast<EP*>(p));
                        p->setHID(j+1);
                        int distance_between_hospitals = hospitalDistances[i][j];
                        p->setDistance(p->getDistance() + hospitalDistances[i][j]);
						served = true;
						break;
					}
				}
				if (!served)
				{
					cout << endl << "One EP could not be served by the hospitals in the area." << endl;
				}
            }

            if (p == nullptr && c == nullptr)
                break;
        }
     }

}


void Organizer::cars_handling() {

    //car from out to back
    while(true) {
        Car* c = nullptr;
        int priority = 0;
        out_cars->peek(c, priority);
        if (c && -priority == curtime)
        {
            out_cars->dequeue(c, priority);
            back_cars->enqueue(c, -c->getFinish_time());

        }
        else { break; }
    }


    // car from back to its hospital
    while (true) {
        Car* c = nullptr;
        int priority = 0;
        back_cars->peek(c, priority);
        if (c && -priority == curtime)
        {
            back_cars->dequeue(c, priority);
            c->startCheckup(curtime); // Set the checkup start time
            hospitals[c->getHID() - 1].addToCheckupList(c);
            if (c->gettype() == 0) {
                hospitals[c->getHID()-1].addNCar(c);
            }
            else if (c->gettype() == 1) {
                hospitals[c->getHID()-1].addSCar(c);
            }
            finished_list->enqueue(c->getPatient());
            c->removePatient();

        }
        else { break; }
    }


}


bool Organizer::choice()
{
    cout << "Select a mode , press 1 for interactive mode and 2 for silent mode: ";
    int x;
    cin >> x;
    setmode(x);
    if (getmode() == 1)
    {
        return true;
    }
    else if (getmode() == 2)
    {
        return false;

    }
    else {
        cout << "please enter a valid mode";
        choice();
    }
}

void Organizer::simulation() {
    load();
    setTime(1);

    bool isInteractive = choice(); // Prompt user for interactive or silent mode

    while (true) {
        cars_handling();

        // Checkup handling for all hospitals
        for (int i = 0; i < num_of_hospitals; ++i) {
            hospitals[i].checkup(curtime);
        }

        iterate();

        // Increment simulation time
        setTime(curtime + 1);

        if (isInteractive) {
            UI ui;
            ui.print_cur_timestep(hospitals, curtime, num_of_hospitals, out_cars, back_cars);
            system("pause");
        }

        if (NumReq == finished_list->count_q()) {
            break;
        }
    }

    outputfile(); // Output results after simulation ends
}




void Organizer::outputfile() {
    int total_wait_time = 0;
    int patient_count = 0;

    std::ofstream outFile("output.txt");
    if (outFile) {

        outFile << "PID HID Distance RequestTime" << std::endl;

 
        Patient* pp;
        while (finished_list->dequeue(pp)) { 
            outFile << pp->getPID() << " "
                << pp->getHID() << " "
                << pp->getDistance() << " "
                << pp->getRequestTime() << std::endl;

            total_wait_time += pp->getDistance(); 
            patient_count++;
        }

        outFile << "---------------------------------------------" << std::endl;
        outFile << "Total Patients Processed: " << patient_count << std::endl;
        outFile << "Total Hospitals: " << num_of_hospitals << std::endl;
        outFile << "Avg Wait Time: "
            << (patient_count > 0 ? total_wait_time / patient_count : 0)
            << std::endl;
        outFile << "Total Cancelled Requests: " << NumCancReq << std::endl;
        outFile << "Emergency Requests: " << NumEPReq << std::endl;
        outFile << "Normal Requests: " << NumNPReq << std::endl;
        outFile << "Special Requests: " << NumSPReq << std::endl;
    }   

    outFile.close();
}


