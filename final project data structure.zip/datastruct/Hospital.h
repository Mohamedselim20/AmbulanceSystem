#include "OutCar.h"


class hospital
{
	NPQueue np_list;
	priQueue<EP*> ep_list;
	SPQueue sp_list;
	LinkedQueue<Car*> ncars;
	LinkedQueue<Car*> scars;
	LinkedQueue<Car*> checkuplist;
	int NCarSpeed;
	int SCarSpeed;
	int hid;
public:
	hospital();
	void setID(int hid);
	void print_cars();
	void print();
	NPQueue getNPList() const;
	priQueue<EP*> getEPList() const;
	SPQueue getSPList() const;
	void addNP(NP* np);
	void addSP(SP* sp);
	void addEP(EP* ep);

	void setNCarSpeed(int speed);
	void setSCarSpeed(int speed);

	void addNCar(Car* ncar);
	void addSCar(Car* scar);
	bool isEmpty();

	bool carsIsEmpty();

	void cancel_np(NP* np);

	LinkedQueue<Car*>& getNCars();
	LinkedQueue<Car*>& getSCars();
	NPQueue& getNPList();
	priQueue<EP*>& getEPList();
	SPQueue& getSPList();
	int getHID() const;
	void addToCheckupList(Car* car);
	void checkup(int cur);
	Patient* serve_patient(Car*& c, int ct);
};

