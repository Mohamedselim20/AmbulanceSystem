#include "UI.h"
class Organizer
{
private:
	int num_of_hospitals;
	int SCar_speed;
	int NCar_speed;

	LinkedQueue<Patient*>* all_patient_list;
	NPQueue* cancelled_list;
	LinkedQueue<Patient*>* finished_list;
	priQueue<Car*>* back_cars;
	OutCarsQueue* out_cars;

	hospital* hospitals;

	int cur_hospital = 0;
	int curtime;

	int NumReq = 0;
	int NumEPReq = 0;
	int NumNPReq = 0;
	int NumSPReq = 0;
	int NumCancReq = 0;
	int mode;
	int** hospitalDistances;
public:
	Organizer()
	{
		curtime = 0;
		all_patient_list = new LinkedQueue<Patient*>;
		cancelled_list = new NPQueue;
		finished_list = new LinkedQueue<Patient*>;
		back_cars = new priQueue<Car*>;
		out_cars = new OutCarsQueue;
		//these informtion should be loaded from the input file:
		num_of_hospitals = 0;
		hospitals = new hospital[num_of_hospitals];
		SCar_speed = 0;
		NCar_speed = 0;
		
	}
	bool choice();
	int getmode() {
		return mode;
	}
	void setmode(int m)
	{
		mode = m;
	}
	void add_patient(Patient* new_p);
	void add_cancelled_p(NP* new_p);
	void add_finished_p(Patient* new_p);
	
	int getHospNum() const;
	void setHospNum(int hosp_num);

	hospital* getHospitals() const;

	priQueue<Car*>* getBackCars() const;
	void add_back_car(Car* c, int pri);

	OutCarsQueue* getOutCars() const;
	void add_out_car(Car* c, int pri);

	bool patients_empty();
	bool hospitals_empty();
	int getTime() const;
	void setTime(int time);

	~Organizer()
	{
		delete[] hospitals; 
	}

	void load();
	void cars_handling();
	void iterate();
	void simulation();
	bool isEmpty();
	void outputfile();

};