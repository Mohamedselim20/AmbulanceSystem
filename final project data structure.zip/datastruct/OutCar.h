#pragma once
#include "priQueue.h"

class OutCarsQueue : public priQueue<Car*>
{
public:
	void print();

	Car* cancel(int pid);
};
