#include "Organizer.h";
using namespace std;


int main()
{
	Organizer admin;
	UI ui;
	admin.simulation();
}