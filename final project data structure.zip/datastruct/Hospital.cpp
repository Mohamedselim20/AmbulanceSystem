#include "Hospital.h"

hospital::hospital()
{
	NCarSpeed = 0;
	SCarSpeed = 0;
	hid = 0;
}

void hospital::setID(int hid)
{
	this->hid = hid;
}


void hospital::print_cars()
{
	cout << "Free Cars: " << scars.count_q() << "SCars, " << ncars.count_q() << "NCars";

}

void hospital::print() {
	std::cout << "Hospital ID: " << hid << std::endl;

	cout << "EP requests: ";
	ep_list.print();
	cout << std::endl;

	cout << "SP requests: ";
	sp_list.print();
	cout << std::endl;

	cout << "NP requests: ";
	np_list.print();
	cout << std::endl;

	cout << "Checkup List: ";
	if (checkuplist.isEmpty()) 
	{

		cout << "Empty" << std::endl;
	}
	else {
		LinkedQueue<Car*> temp_queue;
		Car* temp_car;

		while (checkuplist.dequeue(temp_car)) 
		{
			cout << "[Car ID: " << temp_car->getID()
				<< ", Type: " << (temp_car->gettype() == 0 ? "NC" : "SC")
				<< "], ";
			temp_queue.enqueue(temp_car); 
		}
		cout << endl;

		while (temp_queue.dequeue(temp_car)) 
		{
			checkuplist.enqueue(temp_car);
		}
	}
	print_cars();
	cout << std::endl;
}

void hospital::addToCheckupList(Car* car) 
{
	checkuplist.enqueue(car); 
	cout << "Car ID: " << car->getID() << " added to checkup list of Hospital ID: " << hid << endl;
}

void hospital::checkup(int current_time) {
	Car* car;
	LinkedQueue<Car*> temp_queue;

	while (!checkuplist.isEmpty()) {
		checkuplist.dequeue(car);

		// Check if the car's checkup is done
		if (car->isCheckupComplete(current_time)) {
			if (car->gettype() == 0) {
				ncars.enqueue(car); // Move NC to free list
			}
			else if (car->gettype() == 1) {
				scars.enqueue(car); // Move SC to free list
			}
		}
		else {
			temp_queue.enqueue(car); // Keep the car in the checkup list
		}
	}

	// Restore cars still undergoing checkup back to the checkuplist
	while (!temp_queue.isEmpty()) {
		temp_queue.dequeue(car);
		checkuplist.enqueue(car);
	}
}




NPQueue hospital::getNPList() const
{
	return np_list;
}

priQueue<EP*> hospital::getEPList() const
{
	return ep_list;
}

SPQueue hospital::getSPList() const
{
	return sp_list;
}

void hospital::addNP(NP* np)
{
	np_list.enqueue(np);
}

void hospital::addSP(SP* sp)
{
	sp_list.enqueue(sp);
}

void hospital::addEP(EP* ep)
{
	ep_list.enqueue(ep, ep->getSeverity());
}

void hospital::setNCarSpeed(int speed)
{
	NCarSpeed = speed;
}

void hospital::setSCarSpeed(int speed)
{
	SCarSpeed = speed;
}

void hospital::addNCar(Car* ncar)
{
	ncars.enqueue(ncar);
}

void hospital::addSCar(Car* scar)
{
	scars.enqueue(scar);
}

bool hospital::isEmpty()
{
	return np_list.isEmpty() && sp_list.isEmpty() && ep_list.isEmpty();
}
bool hospital::carsIsEmpty()
{
	return ncars.isEmpty() && scars.isEmpty();
}

void hospital::cancel_np(NP* np)
{
	np_list.cancel(np->getPID());
}

LinkedQueue<Car*>& hospital::getNCars() {
	return ncars;
}

LinkedQueue<Car*>& hospital::getSCars() {
	return scars;
}

NPQueue& hospital::getNPList() {
	return np_list;
}

priQueue<EP*>& hospital::getEPList() {
	return ep_list;
}

SPQueue& hospital::getSPList() {
	return sp_list;
}

int hospital::getHID() const {
	return hid;
}

Patient* hospital::serve_patient(Car*& c, int ct)
{
	
	// Handle EP first
	if (!ncars.isEmpty() && !ep_list.isEmpty())
	{
		EP* ep;
		int pri;
		ncars.dequeue(c);
		ep_list.dequeue(ep, pri);
		c->assign_patient(ep, ct);
		return nullptr;
	}
	else if (ncars.isEmpty() && !ep_list.isEmpty() && !scars.isEmpty())
	{
		EP* ep;
		int pri;
		scars.dequeue(c);
		ep_list.dequeue(ep, pri);
		c->assign_patient(ep, ct);
		return nullptr;
	}
	else if (ncars.isEmpty() && scars.isEmpty() && !ep_list.isEmpty())
	{
		EP* ep;
		int pri;
		ep_list.dequeue(ep, pri);
		return ep;
	}
	else if (!ncars.isEmpty() && !np_list.isEmpty())
	{
		NP* np;
		ncars.dequeue(c);
		np_list.dequeue(np);
		c->assign_patient(np, ct);
		return nullptr;
	}
	else if (!scars.isEmpty() && !sp_list.isEmpty())
	{
		SP* sp;
		scars.dequeue(c);
		sp_list.dequeue(sp);
		c->assign_patient(sp, ct);
		return nullptr;
	}
	

	c = nullptr;
	return nullptr;
}
