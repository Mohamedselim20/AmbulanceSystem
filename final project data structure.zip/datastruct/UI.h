#pragma once
#include "Hospital.h"

class UI
{
public:

	hospital* hp;

	void print_cur_timestep(hospital* hospitals, int curtime, int hosp_num, OutCarsQueue* out_cars, priQueue<Car*>* back_cars)
	{
		cout << "Current Timestep: " << curtime <<endl;
		for (int i = 0; i < hosp_num; i++)
		{
			cout << "================    HOSPITAL #" << i+1 << " data    ================" << endl;
			hospitals[i].print();
			cout << "================    HOSPITAL #" << i+1 << " data  end ==============" << endl;
			cout << "---------------------------------------------------------------";
			cout << endl;
		}
		cout << endl;
		out_cars->print();
		cout << endl;
		cout << back_cars->count_q() << " <== Back cars: ";
		back_cars->print_noh();
		cout << endl;
	}

};
